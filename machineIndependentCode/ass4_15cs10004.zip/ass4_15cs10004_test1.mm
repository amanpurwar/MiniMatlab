// Test Declaration
int test = 2;
double d = 2.3;
int i;
Matrix m[2][3];
int a = 4, *p, b;
void func(int i, double d,Matrix a[2][2]);
char c;

int main () {
	double e = 2.3;
	int f;
	Matrix temp[2][2] = {1.1,2.1;3.3,3.4};
	int r = 4, *q, y;
	char h;
}