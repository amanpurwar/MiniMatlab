// Test Expressions
int test = 1;
int main () {
	int a=1, b=2, c;
	c = a + b;
	a++;
	a = a>>2;
	b = a / b;
	double d;
	d = a+d;
	a = b > a ? b : a;
	int check = a+b*c;
	if (check < c) 
		c = a|b;
	i = ++a + b++;
	Matrix m[2][3],n[2][3],p[3][2],q[2][2],a[2][2] = {1.2,2.3;3.2,3.4};
	m = m + n;
	p = n.';
	q = m*p;
	q = q - a;
}